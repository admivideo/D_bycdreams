<?php if(homey_show_google_reCaptcha()): ?>
<div class="form-group captcha_wrapper">
    <div class="homey_google_reCaptcha"></div>
</div>
<?php endif; ?>