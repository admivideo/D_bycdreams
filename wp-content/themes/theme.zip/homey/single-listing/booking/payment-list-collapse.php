<div id="homey_booking_cost" class="payment-list">
    <?php echo homey_calculate_booking_cost_instance(); ?>
</div><!-- payment-list --> 