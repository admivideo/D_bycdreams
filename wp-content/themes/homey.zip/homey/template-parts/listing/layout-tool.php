<!-- <ul class="layout-tool list-inline text-right">
	<li class="layout-tool-title"><strong><?php esc_html_e('View', 'homey'); ?></strong>:</li>
	<li class="view-btn btn-list "><i class="fa fa-th-list"></i></li>
	<li class="view-btn btn-grid"><i class="fa fa-th-large"></i></li>
</ul> -->